
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.opensymphony.xwork2.ActionSupport;

public class MyLogin extends ActionSupport{
	private static final long serialVersionUID = 1L;
	private String Email;
	   private String Password;
	   private String FirstName, LastName,PhoneNumber,CompanyName,City,Country;

	   public String execute() {
	      String ret = ERROR;
	      Connection conn = null;

	      try {
	         String URL = "jdbc:mysql://localhost/miniproject1";
	         Class.forName("com.mysql.jdbc.Driver");
	         conn = DriverManager.getConnection(URL, "root", "");
	         String sql = "SELECT FirstName, LastName, Email, PhoneNumber,CompanyName,City, Country, Password FROM user WHERE";
	         sql+=" Email = ? AND Password = ?";
	         PreparedStatement ps = conn.prepareStatement(sql);
	         ps.setString(1, Email);
	         ps.setString(2, Password);
	         ResultSet rs = ps.executeQuery();

	         while (rs.next()) {
	            FirstName = rs.getString(1);
	            LastName = rs.getString(2);
	            Email= rs.getString(3);
	            PhoneNumber = rs.getString(4);
	            CompanyName = rs.getString(5);
	            City = rs.getString(6);
	            Country = rs.getString(7);
	            Password = rs.getString(8);
	            
	            ret = "success";
	         }
	      } catch (Exception e) {
	         ret = "error";
	      } finally {
	         if (conn != null) {
	            try {
	               conn.close();
	            } catch (Exception e) {
	            }
	         }
	      }
	      return ret;
	   }

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		Country = country;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}


}
