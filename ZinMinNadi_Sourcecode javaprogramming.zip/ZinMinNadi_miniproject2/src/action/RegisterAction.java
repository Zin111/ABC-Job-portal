package action;

import com.opensymphony.xwork2.ActionSupport;

import dao.RegisterDao;


public class RegisterAction extends ActionSupport {

	private static final long serialVersionUID = 1L;
	private String  FirstName,LastName,Email,PhoneNumber,CompanyName,City,Country,Password;
	private String msg = "";
	
	RegisterDao sdo = null;
	int ctr = 0;
	
	public String execute() throws Exception{
		sdo = new RegisterDao();
			ctr = sdo.registerUser( FirstName,LastName,Email,PhoneNumber,CompanyName,City,Country,Password);
			if (ctr > 0) {
				//msg = "Registration Successfull";
				return "login1";
			} else {
				return "REGISTER";
			}
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstname) {
		this.FirstName = firstname;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastname) {
		this.LastName = lastname;
	}
	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		this.Email = email;
	}
	
	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phonenumber) {
		this.PhoneNumber = phonenumber;
	}
	
	
	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyname) {
		this.CompanyName = companyname;
	}
	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		this.City = city;
	}
	
	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		this.Country = country;
	}
	
	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		this.Password = password;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public int getCtr() {
		return ctr;
	}

	public void setCtr(int ctr) {
		this.ctr = ctr;
	}
}

	

