package action;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.opensymphony.xwork2.ActionSupport;

import bean.RegisterBean;
import dao.RegisterDao;


public class ReportAction extends ActionSupport{

	
	private static final long serialVersionUID = 1L;
	
	ResultSet rs = null;
	RegisterBean bean = null;
	List<RegisterBean> beanList = null;
	RegisterDao admin = new RegisterDao();
	private boolean noData = false;

	@Override
	public String execute() throws Exception {
		try {
			beanList = new ArrayList<RegisterBean>();
			rs = admin.report();
			int i = 0;
			if (rs != null) {
				while (rs.next()) {
					i++;
					bean = new RegisterBean();
					
					bean.setFirstName(rs.getString("FirstName"));
					bean.setLastName(rs.getString("LastName"));
					bean.setEmail(rs.getString("Email"));
					bean.setPhoneNumber(rs.getString("PhoneNumber"));
					bean.setCompanyName(rs.getString("CompanyName"));
					bean.setCity(rs.getString("City"));
					bean.setCountry(rs.getString("Country"));
					bean.setPassword(rs.getString("Password").replaceAll("(?s).", "*"));
					
					beanList.add(bean);
				}
			}
			if (i == 0) {
				noData = false;
			} else {
				noData = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "REPORT";
	}

	public boolean isNoData() {
		return noData;
	}

	public void setNoData(boolean noData) {
		this.noData = noData;
	}

	public List<RegisterBean> getBeanList() {
		return beanList;
	}

	public void setBeanList(List<RegisterBean> beanList) {
		this.beanList = beanList;
	}
}


