package action;

import java.util.Map;
import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.SessionAware;

import dao.LoginDao;



public class Login implements SessionAware{
private String email,password;
SessionMap<String,String> sessionmap;

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getUserpass() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String execute(){
	if(LoginDao.validate(email, password)){
		return "success";
	}
	else{
		return "error";
	}
}

public void setSession(Map map) {
	sessionmap=(SessionMap)map;
	sessionmap.put("login","true");
}

public String logout(){
	sessionmap.invalidate();
	return "success";
}

}
