package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RegisterDao 
	{

	// method for create connection
		public static Connection getConnection() throws Exception {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				return DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/miniproject1?useSSL=false", "root", "");
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
	// method for save user data in database
	public int registerUser(String FirstName, String LastName, String Email, String PhoneNumber, String CompanyName, String City, String Country, String Password) throws Exception {
		int i = 0;
		try {
			String sql = "insert into user" + 
					"(FirstName,LastName,Email,PhoneNumber,CompanyName,City,Country,Password) values"+
					"(?,?,?,?,?,?,?,?);";
		
			PreparedStatement ps = getConnection().prepareStatement(sql);
		
			
			ps.setString(1, FirstName);
			ps.setString(2, LastName);
			ps.setString(3, Email);
			ps.setString(4, PhoneNumber);
			ps.setString(5, CompanyName);
			ps.setString(6, City);
			ps.setString(7, Country);
			ps.setString(8, Password);
			i = ps.executeUpdate();
			return i;
		} catch (Exception e) {
			e.printStackTrace();
			return i;
		} finally {
			if (getConnection() != null) {
				getConnection().close();
			}
		}
	}
	// method for fetch saved user data
		public ResultSet report() throws SQLException, Exception {
			ResultSet rs = null;
			try {
				String sql = "SELECT FirstName,LastName,Email,PhoneNumber,CompanyName,City,Country,Password FROM user";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				rs = ps.executeQuery();
				return rs;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			} finally {
				if (getConnection() != null) {
					getConnection().close();
				}
			}
		}

		// method for fetch old data to be update
		public ResultSet fetchUserDetails(String Email) throws SQLException, Exception {
			ResultSet rs = null;
			try {
				String sql = "SELECT FirstName,LastName,Email,PhoneNumber,CompanyName,City,Country,Password FROM user WHERE Email=?";
				PreparedStatement ps = getConnection().prepareStatement(sql);
				ps.setString(1, Email);
				rs = ps.executeQuery();
				return rs;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			} finally {
				if (getConnection() != null) {
					getConnection().close();
				}
			}
		}

		// method for update new data in database
		public int updateUserDetails(String FirstName, String LastName, String Email, String PhoneNumber, String CompanyName, String City, String Country, String Password,String Emailhidden)
				throws SQLException, Exception {
			getConnection().setAutoCommit(false);
			int i = 0;
			try {
				String sql = "UPDATE user SET FirstName=?,LastName=?,Email=?,PhoneNumber=?,CompanyName=?,City=?,Country=?,Password=? WHERE Email=?";
				PreparedStatement ps = (PreparedStatement) getConnection().prepareStatement(sql);
				ps.setString(1, FirstName);
				ps.setString(2, LastName);
				ps.setString(3, Email);
				ps.setString(4, PhoneNumber);
				ps.setString(5, CompanyName);
				ps.setString(6, City);
				ps.setString(7, Country);
				ps.setString(8, Password);
				ps.setString(9, Emailhidden);
				i = ps.executeUpdate();
				return i;
			} catch (Exception e) {
				e.printStackTrace();
				getConnection().rollback();
				return 0;
			} finally {
				if (getConnection() != null) {
					getConnection().close();
				}
			}
		}

}



